<!DOCTYPE html>
<!--
    Licensed to the Apache Software Foundation (ASF) under one
    or more contributor license agreements.  See the NOTICE file
    distributed with this work for additional information
    regarding copyright ownership.  The ASF licenses this file
    to you under the Apache License, Version 2.0 (the
    "License"); you may not use this file except in compliance
    with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing,
    software distributed under the License is distributed on an
    "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
     KIND, either express or implied.  See the License for the
    specific language governing permissions and limitations
    under the License.
-->
<html lang="en">
    <head>
        <!--
        Customize this policy to fit your own app's needs. For more guidance, see:
            https://github.com/apache/cordova-plugin-whitelist/blob/master/README.md#content-security-policy
        Some notes:
            * gap: is required only on iOS (when using UIWebView) and is needed for JS->native communication
            * https://ssl.gstatic.com is required only on Android and is needed for TalkBack to function properly
            * Disables use of inline scripts in order to mitigate risk of XSS vulnerabilities. To change this:
                * Enable inline JS: add 'unsafe-inline' to default-src
        -->
        <meta http-equiv="Content-Security-Policy" content="default-src 'self' data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; img-src 'self' data: content:;">
        <meta name="format-detection" content="telephone=no">
        <meta name="msapplication-tap-highlight" content="no">
        <meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
        <script type="text/javascript" src="js/jquery-3.1.1.js"></script>
        <script type="text/javascript" src="js/bootstrap.js"></script>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/index.css">
        <title>CWU SOURCE</title>
    </head>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a href="index.html" class="navbar-brand"><b>CWU SOURCE</b></a>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="mainNavBar">
                    <ul class="nav navbar-nav">
                        <li><a href="ScheduleAtAGlance.html">Program At A Glance</a></li>
                        <li><a href="#">Schedule</a></li>
                        
                        <li class="dropdown">
                          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Presentations<span class="caret"></span>
                          </a>
                          <ul class="dropdown-menu">
                            <li><a href="#">Panels</a></li>
                            <li><a href="#">Oral Presentations</a></li>
                            <li><a href="#">Poster Presentations</a></li>
                            <li><a href="#">Creative Expression Presentations</a></li>
                            <li><a href="#">Constructed and Creative Objects</a></li>
                          </ul>
                        </li>

                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>
  
 
<form action="test2.php" method="post" >  
Search: 
 
<input type="text" name="name" size='30' />
<input type="submit" value="Send" /> <br /> <br /> 
Narrow Your Search:  
    <select name="selectVal">
	    <option value="null" name="null">Null</option>
        <option value="firstname" name="firstname">first name</option>
        <option value="lastname">last name</option>
        <option value="type">type</option>
        <option value="department">department</option>
        <option value="keywords">keywords</option>
    </select> 


</form>

<?php
include ("config.php");
   
$id= $abstract= $keywords= $department= $type= $value = $result= $rows= $fname= $lname = $row=   "";
 
 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
       $id = $_POST["name"];
	   $value= $_POST["selectVal"];
	
	if ($value == 'null'){
        $sql = "SELECT firstname, keywords, abstract, lastname, type, department FROM test WHERE abstract like '%$id%' OR keywords like '%$id%' OR department like '%$id%' OR type like '%$id%' OR firstname like '%$id%' OR lastname like '%$id%' OR first_name like '%$id%' OR last_name like '%$id%'";
    }
	
	
	elseif ($value == 'type'){
		$sql = "SELECT firstname, keywords, abstract, lastname, type, department FROM test WHERE type like '%$id%'";

    }
    
	elseif ($value == 'firstname'){
		$sql = "SELECT firstname, keywords, abstract, lastname, type, department FROM test WHERE firstname like '%$id%' OR first_name like '%$id%'";
    }
	
	elseif ($value == 'lastname'){
	    $sql = "SELECT firstname, keywords, abstract, lastname, type, department FROM test WHERE lastname like '%$id%'";
    }
	
	elseif ($value == 'department'){
		$sql = "SELECT firstname, keywords, abstract, lastname, type, department FROM test WHERE department like '%$id%'";
                   
    }
	
	elseif ($value == 'keywords'){
	    $sql = "SELECT firstname, keywords, abstract, lastname, type, department FROM test WHERE keywords like '%$id%'";
    }	
	
	

																							
      
	 $result = mysqli_query($conn,$sql);
	 
	$found=0;
      while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
	        $found=1;
			 $fname=$row['firstname'];
			 $lname=$row['lastname'];
			 $type=$row['type'];
			 $department=$row['department'];
			 $keywords=$row['keywords'];
             $abstract=$row['abstract'];
           
            echo 
			"<div>
			<h3>  $department </h3>
			<h4> $fname&nbsp;$lname</h4>
            <p> $abstract </p>
			</div> ";
        }
		
	if ($found==0) {
       echo "<p>&nbsp;</p>
	   <p> no results found </p>";
	 
	 }
    }	

   ?>
 

</body>
</html>