﻿var XLSX = require('../');
var testCommon = require('./Common.js');

var file = 'interview.xlsx';

describe(file, function () {
	testCommon(file);
});