/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

document.addEventListener('deviceready', onDeviceReady, false);

    var input = document.getElementById('in');
    var table = document.getElementById("mytable");
    var db;

    // Handles modal table 
    $('table').on('click', 'tr', function(e){
         $("#myModal").modal("show");
         //$("#txtfname").val($(this).closest('tr').children()[0].textContent);
         //$("#txtlname").val($(this).closest('tr').children()[1].textContent);
         $("#startTime").html("<b>Start time:</b> " + $(this).closest('tr').children()[1].textContent);
         $("#location").html("<b>Location:</b> " + $(this).closest('tr').children()[2].textContent);
         var title = "'" + $(this).closest('tr').children()[3].textContent + "'";
         $("#myModal").find('.modal-title').html("<b>" + $(this).closest('tr').children()[3].textContent + "</b>");
         db.readTransaction(function (txn) {

            //Sql call for Abstracts, Date and Authors 
            txn.executeSql('SELECT Abstract, Date, AuthorF1, AuthorL1, AuthorF2, AuthorL2, AuthorF3, AuthorL3, AuthorF4, AuthorL4, AuthorF5, AuthorL5 FROM data WHERE PanelTitle = ' + title, [], function (tx, res) {
                $("#abstract").html(res.rows.item(0)["Abstract"]);
                $("#date").html("<b>Date:</b> " + res.rows.item(0)["Date"]);
                var authors = [];
                authors.push("" + res.rows.item(0)["AuthorF1"]); // 0
                authors.push("" + res.rows.item(0)["AuthorL1"]);
                authors.push("" + res.rows.item(0)["AuthorF2"]); // 2
                authors.push("" + res.rows.item(0)["AuthorL2"]);
                authors.push("" + res.rows.item(0)["AuthorF3"]); // 4
                authors.push("" + res.rows.item(0)["AuthorL3"]);
                authors.push("" + res.rows.item(0)["AuthorF4"]); // 6
                authors.push("" + res.rows.item(0)["AuthorL4"]);
                authors.push("" + res.rows.item(0)["AuthorF5"]); // 8
                authors.push("" + res.rows.item(0)["AuthorL5"]);
                $("#authors").html("<b>Author(s):</b> " );
                var authorz = document.getElementById('authors');
                if (authors[0] !== "UNDEFINED") {
                  authorz.innerHTML = authorz.innerHTML + authors[0] + " " + authors[1];
                }
                for (var i = 2; i < authors.length - 1; i += 2) {
                  if (authors[i] !== "UNDEFINED") {
                    authorz.innerHTML = authorz.innerHTML + ", " + authors[i] + " " + authors[i+1];
                  }
                } 
            }
            );

            //SQL query for Mentors 
             txn.executeSql('SELECT  ProfessorF1, ProfessorL1, ProfessorF2, ProfessorL2, ProfessorF3, ProfessorL3 FROM data WHERE PanelTitle = ' + title, [], function (tx, res) {
                var professors = [];
                professors.push("" + res.rows.item(0)["ProfessorF1"]); // 0 
                professors.push("" + res.rows.item(0)["ProfessorL1"]);
                professors.push("" + res.rows.item(0)["ProfessorF2"]); // 2
                professors.push("" + res.rows.item(0)["ProfessorL2"]);
                professors.push("" + res.rows.item(0)["ProfessorF3"]); // 4
                professors.push("" + res.rows.item(0)["ProfessorL3"]);

                $("#mentors").html("<b>Mentor(s):</b> " );
                
                var authorz = document.getElementById('mentors');
                if (professors[0] !== "UNDEFINED") {
                  mentors.innerHTML = mentors.innerHTML + professors[0] + " " + professors[1];
                }
                for (var i = 2; i < professors.length - 1; i += 2) {
                  if (professors[i] !== "UNDEFINED") {
                    mentors.innerHTML = mentors.innerHTML + ", " + professors[i] + " " + professors[i+1];
                  }
                } 
            }
            );           

         });
         
    });

    /*function runQuery(){
          db.readTransaction(function (txn) {
              txn.executeSql('SELECT StartTime, Date, Location, PanelTitle FROM data', [], function (tx, res) {
          var arr;
          deleteRows();
          for(var i = 0; i < res.rows.length; i++){
            arr = [res.rows.item(i)["Date"], res.rows.item(i)["StartTime"], res.rows.item(i)["Location"], res.rows.item(i)["PanelTitle"]];
            addRow(arr);
          }
              });
            });
    }*/

    // Runs a query sorted by date and then time, and prints to table
    function runQuery(){
          db.readTransaction(function (txn) {
              txn.executeSql('SELECT Date, StartTime, Location, PanelTitle FROM data', [], function (tx, res) {
          input.value = "LUL";
          input.value += res.rows.length;
          var arr = queryToArray(res);
          sortByDateAndTime(arr);
          input.value = arr[0][0];
          updateTable(arr);
              });
            });
    }

    // Scrolls to an index (NOT YET IMPLEMENTED FULLY)
    function scrollToView(){
      var elem = document.getElementsByTagName("tr")[10];  
      elem.scrollIntoView(true); 
    }

      // Deletes all rows from table
      function deleteRows(){
        while(table.rows.length > 1){
          table.deleteRow(1);
        }
      }

      // Adds a row based on an array
      function addRow(arr){
        var row = table.insertRow(-1);
        var cell;
        for(var i = 0; i < arr.length; i++){
          cell = row.insertCell(-1);
          cell.innerHTML = arr[i];
        }
      }

      // Time comparator
      /*function timeComesBefore(time1, time2){
        if(time1.charAt(1) == ':'){
          time1 = '0' + time1;
        }
        if(time2.charAt(1) == ':'){
          time2 = '0' + time2;
        }
        if(time1 > time2){
          return 1;
        }else{
          return -1;
        }
      }*/

      // Date comparator
      /*function dateComesBefore(date1, date2){
        var splitDate1 = date1.split(" ");
        var splitDate2 = date2.split(" ");
        date1 = splitDate1[2].substring(0, 2);
        date2 = splitDate2[2].substring(0, 2);
        if(date1 > date2){
          return 1;
        }else{
          return -1;
        }
      }*/

      // Returns a lexicographically comparable date
      function makeComparableDate(date){
        var splitDate = date.split(" ");
        return splitDate[2].substring(0, 2);
      }

      // Sets the date back to something more readable
      function makeReadableDate(date){
        date = 'May ' + date;
        return date;
      }

      // Returns a lexicographically comparable time
      function makeComparableTime(time){
        if(time.charAt(1) == ':'){
          time = '0' + time;
        }
        return time;
      }

      // Converts query to 2D array
      function queryToArray(res){
        var arr = new Array(res.rows.length);
        for(var i = 0; i < res.rows.length; i++){
          arr[i] = [res.rows.item(i)["Date"], res.rows.item(i)["StartTime"], res.rows.item(i)["Location"], res.rows.item(i)["PanelTitle"]];
        }
        return arr;
      }

      

      // Takes the array of a query output and sorts by date and time
      function sortByDateAndTime(arr){
        for(var i = 0; i < arr.length; i++){
          arr[i][0] = makeComparableDate(arr[i][0]);
          arr[i][1] = makeComparableTime(arr[i][1]);
        }
        arr.sort(function(a, b){
          if(a[0] === b[0]){
            if(a[1] === b[1]){
              return 1;
            }else{
              return (a[1] < b[1]) ? -1 : 1;
            }
          }else{
            return (a[0] < b[0]) ? -1 : 1;
          }
        });
        // Converts dates back to a readable format after sorting in the comparable format
        for(var i = 0; i < arr.length; i++){
          arr[i][0] = makeReadableDate(arr[i][0]);
        }
      }

      // Creates table from passed array
      function updateTable(arr){
        deleteRows();
        for(var i = 0; i < arr.length; i++){
          addRow(arr[i]);
        }
      }

    // Main function that executes when the device is ready
    function onDeviceReady(){
          function copyDatabaseFile(dbName) {

              var sourceFileName = cordova.file.applicationDirectory + 'www/' + dbName;
              var targetDirName = cordova.file.dataDirectory;

              return Promise.all([
          new Promise(function (resolve, reject) {
              resolveLocalFileSystemURL(sourceFileName, resolve, reject);
          }),
          new Promise(function (resolve, reject) {
                    resolveLocalFileSystemURL(targetDirName, resolve, reject);
                })
              ]).then(function (files) {
          var sourceFile = files[0];
          var targetDir = files[1];
                return new Promise(function (resolve, reject) {
                    targetDir.getFile(dbName, {}, resolve, reject);
                }).then(function () {
                    console.log("file already copied");
                }).catch(function () {
                    console.log("file doesn't exist, copying it");
                    return new Promise(function (resolve, reject) {
                      sourceFile.copyTo(targetDir, dbName, resolve, reject);
                  }).then(function () {
                      console.log("database file copied");
                  });
                });
                });
          }

          copyDatabaseFile('mydatabase.db').then(function () {
              // success! :)
              db = sqlitePlugin.openDatabase('mydatabase.db');
        runQuery();
      });
            /*db.readTransaction(function (txn) {
              txn.executeSql('SELECT AuthorF1 FROM data WHERE CAST(EntryID as integer) BETWEEN 1 AND 6', [], function (tx, res) {
                  console.log('Successfully read from pre-populated DB:');
          for(var i = 1; i < res.rows.length; i++){
                    //output.value += (JSON.stringify(res.rows.item(i))) + "\n";
          }
              });
            });
          }).catch(function (err) {
              // error! :(
              console.log(err);
          });*/

      }

$(document).ready(function(){
  $(window).scroll(function(){
    if($(this).scrollTop()>50){
      $('#back-to-top').fadeIn();
    }else{
      $('#back-to-top').fadeOut();
    }
  });

  //scroll back to top
  $('#back-to-top').click(function(){
    $('#back-to-top').tooltip('hide');
    $('body,html').animate({
      scrollTop: o
    }, 800);
    return false;
    });

    $('#back-to-top').tooltip('show'); 
  });




// BACK UP CODE DONT DELETE
/*
var originalConsoleLog = console.log.bind(console);
console.log = function (str) {
  originalConsoleLog(str);
  display.innerHTML += str + '\n';
};
*/
/*
var app = {
  // Application Constructor
  initialize: function () {
    this.bindEvents();
  },
  // Bind Event Listeners
  //
  // Bind any events that are required on startup. Common events are:
  // 'load', 'deviceready', 'offline', and 'online'.
  bindEvents: function () {
    document.addEventListener('deviceready', this.onDeviceReady, false);
  },
  // deviceready Event Handler
  //
  // The scope of 'this' is the event. In order to call the 'receivedEvent'
  // function, we must explicitly call 'app.receivedEvent(...);'
  onDeviceReady: function () {
    //app.receivedEvent('deviceready');

    function copyDatabaseFile(dbName) {

      var sourceFileName = cordova.file.applicationDirectory + 'www/' + dbName;
      var targetDirName = cordova.file.dataDirectory;

      return Promise.all([
        new Promise(function (resolve, reject) {
          resolveLocalFileSystemURL(sourceFileName, resolve, reject);
        }),
        new Promise(function (resolve, reject) {
          resolveLocalFileSystemURL(targetDirName, resolve, reject);
        })
      ]).then(function (files) {
        var sourceFile = files[0];
        var targetDir = files[1];
        return new Promise(function (resolve, reject) {
          targetDir.getFile(dbName, {}, resolve, reject);
        }).then(function () {
          console.log("file already copied");
        }).catch(function () {
          console.log("file doesn't exist, copying it");
          return new Promise(function (resolve, reject) {
            sourceFile.copyTo(targetDir, dbName, resolve, reject);
          }).then(function () {
            console.log("database file copied");
          });
        });
      });
    }

    copyDatabaseFile('mydatabase.db').then(function () {
      // success! :)
      var db = sqlitePlugin.openDatabase('mydatabase.db');
      //alert('db: ' + db);
      db.readTransaction(function (txn) {
        txn.executeSql('SELECT AuthorF1 FROM data', [], function (tx, res) {
          console.log('Successfully read from pre-populated DB:');
          //console.log(JSON.stringify(res.rows.item(0)));
          alert(JSON.stringify(res.rows.item(0)));
        });
      });
    }).catch(function (err) {
      // error! :(
      console.log(err);
    });
  },
  // Update DOM on a Received Event
  receivedEvent: function (id) {
    var parentElement = document.getElementById(id);
    var listeningElement = parentElement.querySelector('.listening');
    var receivedElement = parentElement.querySelector('.received');

    listeningElement.setAttribute('style', 'display:none;');
    receivedElement.setAttribute('style', 'display:block;');

    console.log('Received Event: ' + id);
  }
};

app.initialize();
*/